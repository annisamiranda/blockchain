# blockchain_server
blockchain system built with Node.JS and Socket.IO (Server)
